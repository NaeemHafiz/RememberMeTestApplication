package com.example.rememberme.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import com.example.rememberme.R;

public class SignupActivity extends AppCompatActivity {
    EditText editTextEmail, editTextPassword;
    Button btnsignup;
    CheckBox firebasecheckbox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup);
        initViews();
    }

    private void initViews() {
        editTextEmail = findViewById(R.id.firebaseemail);
        editTextPassword = findViewById(R.id.firebasepassword);
        firebasecheckbox = findViewById(R.id.firebasecheckbox);
        btnsignup = findViewById(R.id.firebasesignup);
        btnsignup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (isValidate())
                    registerUser();
            }
        });

    }

    private void registerUser() {
        Toast.makeText(SignupActivity.this, "hi", Toast.LENGTH_SHORT).show();

    }

    private boolean isValidate() {
        String email = editTextEmail.getText().toString();
        String password = editTextPassword.getText().toString();
        if (email.equals("")) {
            editTextEmail.setError("Please Enter Email");
            return false;
        }
        if (password.equals("")) {
            editTextPassword.setError("Please Enter Password");
            return false;
        }
        return true;
    }
}
