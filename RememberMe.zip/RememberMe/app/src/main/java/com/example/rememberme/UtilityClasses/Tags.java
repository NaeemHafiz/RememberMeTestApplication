package com.example.rememberme.UtilityClasses;

public class Tags {
    public static final String APP_PREFS = "rememberme_prefs";
    public static final String USER_NAME = "name";
    public static final String USER_PASSWORD = "email";
    public static String  USER_saveLogin = "saveLogin";

}
